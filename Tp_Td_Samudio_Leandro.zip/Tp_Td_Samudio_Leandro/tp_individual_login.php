<!DOCTYPE html>
  <html>
   <head>
	<title>Trabajo Practico Talento Digital</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<meta charset="utf-8">
   </head>

  <body background="fondologin.png" style = "text-align: center">
  <h1><u>Login:</u><br></h1><img class="rounded-circle" src="registrado.png" alt="Circle image">

<!-- Ingreso de datos del usuario -->

<form action="tp_individual_login.php" method="POST">
    <p><u><h3>*Ingresar Usuario:</h2></u><input type="text" name="usuario"/></p>
    <p><u><h3>*Ingresar Contraseña:</h2></u><input type="password" name="password"/></p>
    <button type="submit" class="btn btn-primary">Ingresar</button>

</form>

<a href="tp_individual_registrarse.php">
    <h2><br>Registrarse!</h2><br>
</a>

<?php
//    if (!isset($_POST['usuario']) and !isset($_POST['password'])) {
//    Validación por cuestiones de seguridad:
//    die("No se logró vincular las variables");
//    }

function validacion($var)
{
    $ok = true;

    if (!isset($var)){
        echo "<b>La variable".$var."no logró vincularse.</b>";
        $ok = false;
    }
    if (empty($var) or (trim($var) == "")){
        echo "<h7>";?>
        <div class="alert alert-warning" role="alert">
            <strong>"No se ingresó correctamente el usuario y/o contraseña"</strong>
        </div>
<?php
        $ok = false;
    }
    return $ok;
}
    if(empty($_POST)){
    die();
}
    $ok = validacion($_POST['usuario']);
    $ok = validacion($_POST['password']);

function ingresar_al_sistema($usuario,$password,$conexion,$iniciar_sesion){

    $sql =
        'SELECT *
         FROM USUARIO
         WHERE USUARIO.usuario_nombre = "' . $usuario . '"';

    $resultado = mysqli_query($conexion, $sql);
    $fila = mysqli_fetch_array($resultado);
    $logueo = true;

    if (password_verify ($password, $fila["password"])) {
        echo "<h2>";
?>
    <div class="alert alert-primary" role="alert">
     <strong>Logueo Exitoso!</strong> You successfully read this important alert message.
    </div>

<?php
        echo "Logueo exitoso!";

    if($iniciar_sesion){
        session_start();
        $_SESSION['id_usuario'] = $fila["usuario_id"];
        $_SESSION['usuario_nombre'] = $fila["usuario_nombre"];
        }
        echo "</h2>";
        } 
        else {
        echo "<h2>"; ?>
        <div class="alert alert-danger" role="alert">
            <strong>"Falló el logueo, por favor verifique su contraseña o su usuario"</strong>
        </div>
<?php
        echo "</h2>";
        $logueo = false;
    }
        return $logueo;
}

$conexion = mysqli_connect("localhost", "root", "", "Base_De_Datos") or die("No funciona");
    echo "<h1>";?>
     <div class="alert alert-primary" role="alert">
        <strong>"Se realizó la conexión!"</strong>
     </div>
<?php

    $usuario = $_POST['usuario'];
    $password = $_POST['password'];
    $id_usuario = 0;
    $logueo = ingresar_al_sistema($usuario,$password,$conexion,true);

    if ($logueo) {
    //header("Location: listado.php");
?> <div class="spinner-border" role="status">
    <span class="sr-only">Loading...</span>
   </div> 

<?php
    header("location:tp_individual_listar_y_filtrar.php");
    die();

    if ($logueo) {
    echo "<h2> Listado de tareas correspondientes al usuario: $usuario</h2>";
    //borro &id_usuario=$id_usuario de la linea siguiente ya que voy a utilizar $_SESSION['id_usuario']
    echo "<h> <a href='tp_individual_alta_usuario.php?accion=alta'>Agregar tarea</a> <br></h3>";

    $sql =
        'SELECT *
         FROM USUARIO, TAREA
         WHERE USUARIO.usuario_nombre = "' . $usuario . '" and  USUARIO.usuario_id = TAREA.usuario_id';

    $resultado = mysqli_query($conexion, $sql);
    $rowcount = mysqli_num_rows($resultado);

    if ($rowcount == 0){
        die("<h2> $usuario no dispones de tareas para mostrar");
    }

    echo "<table border=1 style=" . '"margin: 0 auto;"' . ">";
    echo "<tr>";
    echo "<th>tarea</th>";
    echo "<th>usuario id</th>";
    echo "<th>fecha creacion de tarea</th>";
    echo "<th>descripcion</th>";
    echo "<th>estado</th>";
    echo "<th>fecha de fin</th>";
    echo "</tr>";

    while ($unRegistro = mysqli_fetch_array($resultado)) {

        $tarea_id    = $unRegistro["tarea_id"];
        $usuario_id  = $unRegistro["usuario_id"];
        $f_creacion  = $unRegistro["f_creacion"];
        $descripcion = $unRegistro["descripcion"];
        $estado      = $unRegistro["estado"];
        $f_fin       = $unRegistro["f_fin"];

        echo "<tr>";
        echo "<td>$tarea_id</td>";
        echo "<td>$usuario_id</td>";
        echo "<td>$f_creacion</td>";
    }
}    

echo "<td> $descripcion <a href='tp_individual_editar.php?accion=modificar&tarea_id=" . $tarea_id . "&id_usuario=" . $usuario_id . "&descripcion=" . $descripcion . "'>Modificar</a>
        <a href='tp_individual_borrar.php?accion=baja&tarea_id=" . $tarea_id . "&id_usuario=" . $usuario_id . " ' onclick=" . '"return confirm()"' . ">Borrar</a></td>";

    if ($estado) {
            $estado_tarea = "En proceso";
        } else {
            $estado_tarea = "Finalizada";
        }
        echo "<td>$estado_tarea</td>";
        echo "<td>$f_fin</td>";
        echo "</tr>";
}

?>
</body>
</html>