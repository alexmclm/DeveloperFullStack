<?php

session_start();

  $usuario = $_SESSION['usuario_nombre'];
  $usuario_id = $_SESSION['id_usuario'];
?>

<!DOCTYPE html>
<html>
 <head>
  <title>Listado de tareas!</title>
 </head>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <body background="fondotareas.jpg" style="text-align: center;" >
  <h1><br><br><u>Bienvenido <?php echo $usuario ?> a su lista de tareas!</u></h1>
  <h2><br>Tareas correspondientes al usuario: <?php  echo  "$usuario";?></h2>
  <h3><br><a href='tp_individual_alta_tarea.php?'>Agregar una tarea!</a><br></h3>
  <h3><br><a href='tp_individual_login.php?'>Regresar a la pantalla de Login!</a><br><br></h3>
<?php

$conexion = mysqli_connect("localhost", "root", "", "Base_De_Datos") 
    or die("No funciona.<br><br>");

$sql =
    'SELECT *
     FROM  TAREA
     WHERE TAREA.usuario_id = "' . $usuario_id . '"';

$resultado = mysqli_query($conexion, $sql);
$rowcount = mysqli_num_rows($resultado);

    if ($rowcount == 0){
    die("<h2> $usuario no tiene tareas para mostrar!</h2>");
}

  echo "<table border=1 style=" . '"margin: 0 auto;"' . ">";
  echo "<tr>";
  echo "<th> Tarea </th>";
  echo "<th> Usuario id </th>";
  echo "<th> Fecha Creación de Tarea </th>";
  echo "<th> Descripción </th>";
  echo "<th> Estado </th>";
  echo "<th> Fecha de Fin </th>";
  echo "</tr>";

    while ($unRegistro = mysqli_fetch_array($resultado)) {

    $tarea_id    = $unRegistro["tarea_id"];
    //$usuario_id  = $unRegistro["usuario_id"];
    $f_creacion  = $unRegistro["f_creacion"];
    $descripcion = $unRegistro["descripcion"];
    $estado      = $unRegistro["estado"];
    $f_fin       = $unRegistro["f_fin"];

    echo "<tr>";
    echo "<td>$tarea_id</td>";
    echo "<td>$usuario_id</td>";
    echo "<td>$f_creacion</td>";

$_SESSION["descripcion"] = $descripcion;

    echo "<td> $descripcion <a href='tp_individual_editar.php?tarea_id=" . $tarea_id . "&descripcion=" . $descripcion . "'>Modificar</a>

    <a href='tp_individual_borrar_tarea.php?tarea_id=" . $tarea_id . "' onclick=" . '"return confirm()"' . ">Borrar</a></td>";

    if ($estado) {
        $estado_tarea = "En proceso";
    } else {
        $estado_tarea = "Finalizada";
    }
    echo "<td>$estado_tarea</td>";
    echo "<td>$f_fin</td>";
    echo "</tr>";
}
?>

</body>
</html>