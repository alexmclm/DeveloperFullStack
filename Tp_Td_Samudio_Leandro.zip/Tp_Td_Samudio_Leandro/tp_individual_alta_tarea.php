<!DOCTYPE html>
<html lang="es">
  <head>
   <meta charset="UTF-8">
    <title>Alta de Tarea</title> 
  </head>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<body  background="fondoabm.jpg" style = "text-align: center">

<?php
    session_start();

    if(!isset($_SESSION["id_usuario"]) or !isset($_SESSION['usuario_nombre'])){
        die("Hubo un inconveniente con su sesion.");
    }
    $nick_usuario = $_SESSION['usuario_nombre'];
?>
<form action="tp_individual_alta_tarea.php" method="post">
    <h1><br><br>Bienvenido <?php echo $nick_usuario?> al formulario de alta de tareas!</h1>
    <h3><br>Complete los siguientes campos para agregar una tarea:</h3>
    <p><u><b>*Su Descripción:</u><input type="text" name="descripcion" /></b></p>
    <p><u><b>*Su Contraseña de Usuario:</u><input type="password" name="password" /></b></p>
    <br>
    <button type="submit" class="btn btn-outline-primary">Ingresar Datos</button>
</form>

<?php

    if(empty($_POST)){
//        echo "<h2>Por favor ingrese una nueva tarea y su contraseña para registrarla!</h2>";
        echo '<h2><br><a href="tp_individual_listar_y_filtrar.php">Redirigir al listado de tareas</a></h2>';
        die();
    }
    //$ok = (empty($var) or (trim($var) == ""));
    //echo $_POST["descripcion"];
    //echo $_POST["pass"];
    echo '<h2><a href="tp_individual_listar_y_filtrar.php"> Redirigir al listado de tareas</a> </h2>';

function validar($var)
{
    $ok = true;
    if (!isset($var)){
        echo "La variable :".'$var'."no logró vincularse";
        $ok = false;
    }
    if (empty($var) or (trim($var) == "")){
        echo "El campo solicitado se encuentra vacio!";
        $ok = false;
    }
    return $ok;
}
    if(!validar($_POST['descripcion']) or !validar($_POST['password'])){
        die("<h4>No se ingresaron datos!</h4>");
    }
    
    $password = $_POST["password"];
    $descripcion = $_POST["descripcion"];
    $id_usuario = $_SESSION["id_usuario"];
    
//    echo $id_usuario;
//    echo $_POST["descripcion"];
//    echo $_POST["password"];

///////////////////////////// Conexion a BD /////////////////////////////

    $conexion = mysqli_connect('localhost', 'root', '', 'Base_De_Datos');

///////////////////////////// Ingreso al sistema /////////////////////////
    
function ingresar_al_sistema($usuario,$password,$conexion,$iniciar_sesion){

    $sql =
        'SELECT *
         FROM USUARIO
         WHERE USUARIO.usuario_nombre = "' . $usuario . '"';

    $resultado = mysqli_query($conexion, $sql);
    $fila = mysqli_fetch_array($resultado);
    $logueo = true;

    if (password_verify ($password , $fila["password"])) {
        echo "<h2>";
        echo "Logueo exitoso!";
        if($iniciar_sesion){
            session_start();
            $_SESSION['id_usuario'] = $fila["usuario_id"];
            $_SESSION['usuario_nombre'] = $fila["usuario_nombre"];
        }
        echo "</h4>";
    } else {
        echo "<h2>";
        echo "<h2>";?>
     <div class="alert alert-primary" role="alert">
        <strong>"Falló el logueo, por favor verifique su contraseña o su usuario"</strong>
     </div>
<?php
        echo "</h2>";

        $logueo = false;
    }
    return $logueo;
}
    if(ingresar_al_sistema($nick_usuario, $password, $conexion, false)){
        //echo "<h2> logueo exitoso</h2>";
        $fecha = date("Y-m-d");
        $sql   =
            'INSERT INTO tarea (usuario_id, f_creacion, descripcion, estado)
             VALUES ("' . $id_usuario . '", "' . $fecha . '", "' . $descripcion . '", 1)
                    ';
                 //   echo "<h1>$sql</h1>";
    if($conexion->query($sql) === true) { 
        echo "<h2><br>El registro fue exitoso, se han insertado los siguientes datos:<br><br></h2>";

////////////////////////////// Registro //////////////////////////////

            echo "<table border=1 style=" . '"margin: 0 auto;"' . ">";
            echo "<tr>";
            echo "<th>Usuario id</th>";
            echo "<th>Fecha creacion tarea</th>";
            echo "<th>Descripcion</th>";
            echo "<th>Estado</th> ";
            echo "</tr>";
            echo "<tr>";
            echo "<td>$id_usuario</td>";
            echo "<td>$fecha</td>";
            echo "<td>$descripcion</td>";
            echo "<td>En proceso</td>";
            //echo "<td>$f_fin</td>";
            echo "</tr>";
            echo "</table>";
            echo "<br><br>";

///////////////////////////////////////////////////////////////////
        } else {
            echo "Hubo un error al intentar insertar en la tabla TAREA<br><br>" /* . $conn->error*/;
            echo mysql_errno($conexion) . ": " . mysql_error($conexion) . "\n";
        }
    }
?>

</body>
</html>