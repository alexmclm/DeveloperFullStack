<?php

session_start();

    if(!isset($_SESSION["id_usuario"]) or !isset($_SESSION['usuario_nombre'])){
        die("Hubo un inconveniente con su sesion.");
    }
    $nick_usuario = $_SESSION['usuario_nombre'];

function validar($var)
{
    $ok = true;
    
    if (!isset($var)){
        echo "La variable :".'$var'."no logró vincularse.";
        $ok = false;
    }
    if (empty($var) or (trim($var) == "")){
        echo "La variable :".'$var'."se encuentra vacia.";
        $ok = false;
    }
    return $ok;
}
    if (!empty($_GET)){
        if(!validar($_GET["tarea_id"])){
            die("No funciona por el GET: linea 14");
        }
        $id_tarea   = $_GET["tarea_id"];
        $_SESSION['id_tarea'] = $id_tarea;
        //$id_usuario = $_SESSION["id_usuario"];

        $sql = 'SELECT *
                FROM TAREA
                WHERE   TAREA.tarea_id ='.$id_tarea;

        $conexion   = mysqli_connect('localhost', 'root', '', 'Base_De_Datos');
        $resultado = mysqli_query($conexion,$sql);
        $registro   = mysqli_fetch_array($resultado);
        $descripcion = $registro["descripcion"];
        mysqli_close($conexion);
    }
    if(empty($descripcion)){
         $descripcion = "";
    } 
?>

<!DOCTYPE html>
 <html>
  <head>
    <title>Modificación de tarea</title>
  </head>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<body background="fondoabm.jpg" style="text-align: center;" >

    <h1><br><br>Bienvenido <?php echo $nick_usuario ?> al formulario de modificación de tareas!</h1>
    <form action="tp_individual_editar.php" method="post">

        <h2>Ingrese su contraseña para modificar la tarea: </h2><br>
        <p><b><u>*Descripcion de tarea: <input type="text" name="descripcion" value="<?php echo $descripcion; ?>"/></b></p>
        <p><b><u>*Ingrese su contraseña: <input type="password" name="password" /></b></p>
        <br><br><button type="submit" class="btn btn-primary">Confirmar modificación!</button></p>
    </form>

<?php
///////////////////////////// MODIFICAR /////////////////////////////

   if(!empty($_POST)){
    echo "<h2> Usuario: $nick_usuario </h2>";
    //echo $_POST["id_usuario"], $_POST["accion"], $_POST["pass"];
    $id_usuario = $_SESSION["id_usuario"];
    $password   = $_POST["password"];
    $id_tarea   = $_SESSION['id_tarea'];
    $descripcion = $_POST["descripcion"];

    $conexion   = mysqli_connect('localhost', 'root', '', 'Base_De_Datos');
    $se_logueo = ingresar_al_sistema($nick_usuario, $password, $conexion,false);

    if ($se_logueo) {
        $sql = 'UPDATE TAREA SET tarea.descripcion = "'.$descripcion.'" WHERE tarea_id = '.$id_tarea;
        if ($conexion->query($sql) === true) {
          echo "<h2>SE MODIFICO LA TAREA: $id_tarea <br> DESCRIPCION DE LA TAREA: $descripcion </h2>";
        } else {
          echo "<h2>Ocurrió un error</h2>";
        }
    }
}

function ingresar_al_sistema($usuario,$password,$conexion,$iniciar_sesion){

    $sql =
        'SELECT *
         FROM USUARIO
         WHERE USUARIO.usuario_nombre = "' . $usuario . '"';

    $resultado = mysqli_query($conexion, $sql);
    $fila = mysqli_fetch_array($resultado);
    $logueo = true;

    if (password_verify ($password, $fila["password"])) {
        echo "<h2>";
        echo "Logueo exitoso!";
        if($iniciar_sesion){
            session_start();
            $_SESSION['id_usuario'] = $fila["usuario_id"];
            $_SESSION['usuario_nombre'] = $fila["usuario_nombre"];
        }
        echo "</h2>";
    } else {
        echo "<h2>";
        echo "Falló su logueo, por favor verifique su contraseña o su usuario";
        echo "</h2>";

        $logueo = false;
    }
    return $logueo;
}
?>
    <h2><br><a href="tp_individual_listar_y_filtrar.php">Redirigir al lista de tareas.</a></h2>
    
</body>
</html>