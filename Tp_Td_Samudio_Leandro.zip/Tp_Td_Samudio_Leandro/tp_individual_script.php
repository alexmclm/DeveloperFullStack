<!DOCTYPE html>
 <html>
  <head>
   <title>Script para insertar la base de datos "Base_De_Datos"</title>
  </head>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <body background="mysql.jpg" style="text-align: center;">
  </body>
</html>

<?php
  
  $fecha= date("Y-m-d");

//-------------------------------Script SQL ------------------------------//

$aux = "localhost";

$conexion = mysqli_connect($aux,"root","") or die("No Funciona<br><br>");
  echo "<h3>"; ?>
        <div class="alert alert-success" role="alert">
            <strong>"Se estableció la conexión con la Base De Datos"</strong>
        </div>
<?php
  
  echo"<br>";

$nombreBaseDatos = "Base_De_Datos";

$sql = "CREATE DATABASE $nombreBaseDatos";

  if (mysqli_select_db($conexion, $nombreBaseDatos)){
  echo "<h3>"; ?>
      <div class="alert alert-warning" role="alert">
        <strong>"La base de datos ya ha sido creada"</strong>
      </div>
<?php
  }
  else{
  if ($conexion->query($sql)===true){
  echo "Se creo base de datos $nombreBaseDatos .<br><br>";
  mysqli_select_db($conexion, $nombreBaseDatos);
  }
  else{
  mysqli_close($conexion);
  die("Error al crear base de datos.<br><br>");
  }
}

  $sql = "CREATE TABLE IF NOT EXISTS `usuario` (
  `usuario_id` int NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `usuario_nombre` varchar(80) NOT NULL UNIQUE,
  `password` varchar(100) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `f_creacion` date NOT NULL,
  `nombre_apellido` varchar (50) NOT NULL)";
?>

<div class="card">
  <img src="talento2.jpg">
  <div class="card-body"> CREATE TABLE IF NOT EXISTS `usuario` (
  `usuario_id` int NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `usuario_nombre` varchar(80) NOT NULL UNIQUE,
  `password` varchar(100) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `f_creacion` date NOT NULL,
  `nombre_apellido` varchar (50) NOT NULL); </div>
  </div>

<?php
  
  if ($conexion->query($sql) === TRUE) {
  echo "<h3>"; ?>
    <div class="alert alert-success" role="alert">
      <strong>"La tabla USUARIO ha sido creada satisfactoriamente"</strong>
    </div>
<?php
  } 
  else {
  echo "Hubo un error al crear la tabla usuarios.<br><br>"/* . $conn->error*/;
  echo mysql_error($conexion) . ": " . mysql_error($conexion). "\n";
  }

  $sql = "CREATE TABLE IF NOT EXISTS `tarea` (
  `tarea_id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `usuario_id` int NOT NULL,
  `f_creacion` date NULL,
  `descripcion` varchar(100) NOT NULL,
  `estado` bit(1) NOT NULL,
  `f_fin`  date NOT NULL)";

  if ($conexion->query($sql) === TRUE) {
  echo "<h3>"; ?>
    <div class="alert alert-success" role="alert">
      <strong>"La tabla TAREA ha sido creada satisfactoriamente"</strong>
    </div>
<?php
  } 
  else {
  echo "Hubo un error al crear la tabla usuarios.<br><br>"/* . $conn->error*/;
  echo mysql_error()($conexion) . ": " . mysql_error($conexion). "\n";
}

//-------------------------------------------

  $sql = "ALTER TABLE `tarea` ADD CONSTRAINT `fK_usuario_id` 
  FOREIGN KEY (`usuario_id`)
  REFERENCES `usuario` (`usuario_id`)";

  if ($conexion->query($sql) === TRUE) {
  echo "Se agregó la constraint fK_usuario_nombre a la tabla TAREA.<br><br>";
  } 

?>

<a href="tp_individual_login.php">
  <h2><br>Ir al inicio de sesión!</h2>
  </a>