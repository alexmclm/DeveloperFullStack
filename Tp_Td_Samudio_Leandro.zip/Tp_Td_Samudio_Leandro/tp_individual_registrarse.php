<!DOCTYPE html>
  <html>
   <head>
	<title>Registro de usuario</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
   </head>
<body background="fondologin.png" style = "text-align: center" >

	<h1><u>Alta de Usuario</u><br></h1>
<!--	<img src="mysql.jpg" class="img-fluid" alt="Responsive image"> -->
	<form action = "tp_individual_registrarse.php" method="POST">
	<h2>Bienvenido al fomulario de Alta!</h2> <img class="rounded-circle" src="registrar.png" alt="Circle image">
	<h3>Complete los siguientes datos para terminar su registro en el sistema:</h3>
	<div class="container">
	<p><u><b>Su Usuario:</u><input type="text" name="usuario"/></b></p>
	<p><u><b>Su Contraseña:</u><input type="password" name="password"/></b></p>
	<p><u><b>Su Nombre y Apellido:</u><input type="text" name="name"/></b></p>
	<p><u><b>Su Mail:</u><input type="email" name="mail"/></b></p>
	<br>
	<button type="submit" class="btn btn-outline-primary">Ingresar Datos</button>
	</div>
	<h3><br><a href='tp_individual_login.php?'>Regresar a la pantalla de Login!</a><br><br></h3>
	</form>

<?php

	if (!isset($_POST['usuario']) and !isset ($_POST['password'])
	and !isset($_POST['name']) and !isset ($_POST['mail'])) {
	//Validacion por cuestion de seguridad
	die ("");	
	}
 	if (empty($_POST['usuario']) or trim(($_POST['usuario'])) == "") {
 	echo "<h7>";?>
      <div class="alert alert-warning" role="alert">
    	<strong>"No se ingresó correctamente el usuario"</strong>
	  </div>
<?php
 	die();
 }
 	if (empty($_POST['password']) or trim(($_POST['password'])) == "") {
 	echo "<h7>";?>
      <div class="alert alert-warning" role="alert">
    	<strong>"No se ingresó correctamente la contraseña"</strong>
	  </div>
<?php
 	die();
 }
  	if (empty($_POST['name']) or trim(($_POST['name'])) == "") {
 	echo "<h7>";?>
      <div class="alert alert-warning" role="alert">
        <strong>"No se ingresó correctamente el nombre y apellido"</strong>
	  </div>
<?php
 	die();
 }
  	if (empty($_POST['mail']) or trim(($_POST['mail'])) == "") {
 	echo "<h7>";?>
     <div class="alert alert-warning" role="alert">
      <strong>"No se ingresó correctamente el mail"</strong>
	 </div>
<?php
 	die();
 }
	$usuario = $_POST['usuario'];
	$password = $_POST['password'];
	$name = $_POST['name'];
	$mail = $_POST['mail'];

$conexion = mysqli_connect("localhost", "root", "", "Base_De_Datos") 
	or die ("No funciona<br><br>");
echo"<h3><br>Se estableció la conexión con la base de datos.<br>";

$sql = '
	SELECT * FROM USUARIO WHERE USUARIO.usuario_nombre = "'.$usuario.'" ';

	$resultado = mysqli_query($conexion,$sql);
	$rowcount = mysqli_num_rows($resultado);
	$password = password_hash($password, PASSWORD_BCRYPT);

	if($rowcount == 1){
	  echo"<br><br>";
	  echo "<h2>"; ?>
       <div class="alert alert-warning" role="alert">
         <strong>"Ya existe otro usuario con ese nick, por favor ingrese otro."</strong>
	   </div>
<?php
	  echo"<br>";
	}
	else{
	$fecha= date("Y-m-d");
	$sql = 'INSERT INTO usuario (usuario_nombre, password, mail, f_creacion, nombre_apellido) 
	        VALUES ("'.$usuario.'", "'.$password.'", "'.$mail.'", "'.$fecha.'", "'.$name.'")';
	}
	if ($conexion->query($sql) === TRUE) {
		echo "<h7>"; ?>
    <div class="alert alert-success" role="alert">
    <strong><br>"El registro se completó correctamente, se han insertado los siguientes datos:</strong>
	</div>
<?php

  		echo "<table border=1 style=" . '"margin: 0 auto;"' . ">";
		echo "<tr>";
	    echo "<th>Nick</th>";
	    echo "<th>Password</th>";
	    echo "<th>Mail</th>";
	    echo "<th>Fecha de Creacion de Usuario</th>";
	    echo "<th>Nombre y Apellido</th>";
	    echo "</tr>";

		$usuario = $_POST['usuario'];
		$password = $_POST['password'];
		$name = $_POST['name'];
		$mail = $_POST['mail'];

		echo "<tr>";
	    echo "<td>$usuario</td>";
	    echo "<td>$password</td>";
	    echo "<td>$mail</td>";
	    echo "<td>$fecha</td>";
	    echo "<td>$name</td>";
	    echo "</tr>";
		echo "</table>";
	  	echo"<br><br>";
?>
	<a href="tp_individual_login.php">
	<h2>Volver al inicio de sesión!</h2>
	</a>

<?php
} 
		else {
	    echo "<h2>"; ?>
        <div class="alert alert-danger" role="alert">
    	<strong>"Ocurrió un error al conectarse a la Base de Datos"</strong>
		</div>
<?php
} 

	mysqli_close($conexion);
?>
</body>
</html>