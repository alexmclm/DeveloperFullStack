<?php

    session_start();

function validar($var)
{
    $ok = true;
    if (!isset($var)){
        echo "La variable :".'$var'."no logró vincularse.";
        $ok = false;
    }
    if (empty($var) or (trim($var) == "")){
        echo "El campo solicitado se encuentra vacio.";
        $ok = false;
    }
    return $ok;
}
    if(!isset($_SESSION["id_usuario"]) or !isset($_SESSION['usuario_nombre'])){
        die("Hubo un inconveniente con su sesion.");
    }
    if(empty($_POST)){
        $ok = validar($_GET["tarea_id"]);
        $id_tarea   = $_GET["tarea_id"];
        $_SESSION['id_tarea'] = $id_tarea;
    }
    $id_usuario = $_SESSION["id_usuario"];
    $nick_usuario = $_SESSION['usuario_nombre'];
    //echo "<h1>Bienvenido a BAJA DE TAREAS (GET)</h1>";
?>

<!DOCTYPE html>
  <html>
   <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Borrar Tarea</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
      <body background="fondoabm.jpg" style = "text-align: center">
   </head>
      <body>
    <h1><br><br>Bienvenido <?php echo $nick_usuario ?> al formulario de baja de tareas!</h1>

    <form action="tp_individual_borrar_tarea.php" method="post"><br><br>
                    <h2>Ingrese su contraseña para eliminar la tarea:</h2><br><br>
                    <p><b><u>*Su contraseña de usuario:</b><input type="password" name="password" />
                    <br><br><button type="submit" class="btn btn-primary">Confirmar!</button></p>
    </form>

<h2><br><br><a href="tp_individual_listar_y_filtrar.php">Redirigir al listado de tareas.</a> </h2>
    
      </body>
  </html>
                
<?php
    if(empty($_POST)){
        die();
    }
    //print_r($_POST);
    if(!validar($_POST["password"])){
        die('');
    }
    $id_tarea = $_SESSION['id_tarea'];
    $password   = $_POST["password"];

$conexion   = mysqli_connect('localhost', 'root', '', 'Base_De_datos');

function ingresar_al_sistema($usuario,$password,$conexion,$iniciar_sesion){
    $sql =
        'SELECT *
         FROM USUARIO
         WHERE USUARIO.usuario_nombre = "' . $usuario . '"';

    $resultado = mysqli_query($conexion, $sql);
    $fila = mysqli_fetch_array($resultado);
    $logueo = true;

    if (password_verify ( $password , $fila["password"])) {
        echo "<h2>";
        echo "<h5>";?>
        <div class="alert alert-info" role="alert">
          <strong>Se realizó la conexión!</strong>
        </div>
<?php
        if($iniciar_sesion){
            session_start();
            $_SESSION['id_usuario'] = $fila["usuario_id"];
            $_SESSION['usuario_nombre'] = $fila["usuario_nombre"];
        }
        echo "</h2>";
    } else {
        echo "<h2>";?>
        <div class="alert alert-primary" role="alert">
          <strong>"Falló el logueo, por favor verifique su contraseña o su usuario"</strong>
        </div>
<?php
        echo "</h2>";

        $logueo = false;
    }
    return $logueo;
}
    $se_logueo = ingresar_al_sistema($nick_usuario, $password, $conexion, false);

    if ($se_logueo) {
        $sql = 'DELETE  FROM `tarea` WHERE tarea.tarea_id = ' . "$id_tarea";

        if ($conexion->query($sql) === true) {
            //echo "<h2> se borro la tarea: $id_tarea</h2>";
            echo "<h1>";?>
        <div class="btn btn-success" role="alert">
          <strong>Se ha eliminado la tarea seleccionada!</strong>
        </div>
<?php
        } else {
            echo "<h2>Ocurrió un error</h2>";
        }
    }
?>