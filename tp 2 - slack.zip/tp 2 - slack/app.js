var express = require('express');
var app = express();
var session = require('express-session');
var hbs = require('express-handlebars');
var mongoose = require('mongoose');

// Sesiones
app.use(session({secret: 'UnaClaveMuySecreta'}));

// Handlebars
app.engine('hbs', hbs());
app.set('view engine', 'hbs');


// dependencias de JSON y Formularios

app.use(express.urlencoded());
app.use(express.json());

// Base de datos
mongoose.connect('mongodb://localhost:27017/talento_login', {useNewUrlParser: true, useUnifiedTopology: true});

//--------------- Usuario ---------------

var usuarioSchema = mongoose.Schema({
    usuario: String,
    email: String,
    password: String
});


var Usuario = mongoose.model('Usuario', usuarioSchema);

//--------------- Novedad ---------------

var novedadSchema = mongoose.Schema({
    usuario: String,
    novedad: String
});

var Novedad = mongoose.model('Novedad',novedadSchema);

//--------------- direcciones de novedades ---------------

// muestra un formulario de alta para una novedad
app.get('/alta_novedad', function(req, res) {
    if (!req.session.usuario) {
        res.redirect('/ver_login');
        return;
    }

    res.render('alta_novedades');//devuelve la pantalla de login
});

// hace la persistencia de la novedad en la base de datos y redirecciona al cliente al formulario
// que muestra las novedades
app.post('/registrar_novedad', async function(req, res){

    
    if(req.body.novedad == ""){
        res.render('alta_novedades', {mensaje_error: 'la novedad ingresada es vacia'});
    }else{

    var nov = new Novedad();
    nov.usuario = req.session.usuario;
    nov.novedad = req.body.novedad;
    await nov.save();
    res.redirect('/mostrar');}
});

// muestra las novedades, carga todo en un JSON y lo manda a la plantilla que se encarga de mostrar
app.get('/mostrar', async function(req, res){
    
    lista_novedades = await Novedad.find();

    if (req.session.usuario) {

        res.render('novedades', {listado: lista_novedades.reverse(), mensaje: "<a href='/cerrar_sesion'> cerrar sesión </a>"});
        return
        
    }
    res.render('novedades', {listado: lista_novedades.reverse()})

    
});


//--------------- API --------------- //Realiza API para alta y listado de novedades

// devuelve en un JSON el resultado de la persistencia de una novedad en la base de datos

app.post('/api/alta_novedad', async function(req, res){



    var nov = new Novedad();
    nov.usuario = req.session.usuario;
    nov.novedad = req.body.novedad;
    await nov.save();
    res.json(nov);
    
});

// devuelve en un JSON todas los archivos de la coleccion Novedades
app.get('/api/listado_novedades', async function(req, res){
    
    lista_novedades = await Novedad.find();
    res.json(lista_novedades.reverse());
});

//--------------- USUARIOS Y SESIONES ---------------

app.get('/cerrar_sesion', function(req, res){
    req.session.usuario = null;
    res.redirect('/ver_login');
});

// muestra un formulario de alta de usuario
app.get('/ver_registracion', function(req, res) {
    
    res.render('registracion');//es para devolver un template
});

// si el usuario no exite en la base de datos los guarda y redirecciona a la pantalla de logueo
// caso contrario no guarda los datos y muestra un msj de error
app.post('/registracion', async function(req, res) {
    
    

    if(req.body.password == ""){
        res.render('registracion', {mensaje_error: 'el password no puede ser vacio'});
        return;
    }

    if(req.body.usuario == "" ){
        res.render('registracion', {mensaje_error: 'el usuario no puede ser vacio'});
        return;
    }
    
    if(req.body.email == "" ){
        res.render('registracion', {mensaje_error: 'el email no puede ser vacio'});
        return;
    }

    var usr = await Usuario.findOne({usuario: req.body.usuario});
    
    if (usr) {// si el usuario existe muestra un error 
       
        res.render('registracion', {mensaje_error: 'ya existe otro usuario con el nombre: ' + req.body.usuario, usuario: req.body.usuario});
        return;
    } else {

        var usr = new Usuario();
        usr.usuario = req.body.usuario;
        usr.email = req.body.email;
        usr.password = req.body.password;
        await usr.save();
        req.session.usuario = req.body;
        res.redirect('/ver_login');
    }
});

// muestra el formulario de logueo
app.get('/ver_login', function(req, res) {
    res.render('login');//devuelve la pantalla de login
});


// redirecciona a la pantalla de logueo
app.get('/', function(req, res) {
    res.redirect('/mostrar');
});

app.post('/login', async function(req, res) {
    
    var usr = await Usuario.findOne({usuario: req.body.usuario, password: req.body.password});
    if (usr) {
        req.session.usuario = usr.usuario;
        res.redirect('/mostrar');
        
    } else {
        res.render('login', {mensaje_error: 'Usuario/password incorrecto', usuario: req.body.usuario});
        //usuario: req.body.usuario es para q quede precargado el usuario al momento de loguearse
    }
});


//--------------- API USUARIO ---------------

app.post('/api/registracion', async function(req, res) {
    
    var usr = new Usuario();
    usr.usuario = req.body.usuario;
    usr.email = req.body.email;
    usr.password = req.body.password;
    await usr.save();
    res.json(usr);

});

app.post('/api/login', async function (req, res) {
    
    var usr = await Usuario.findOne({usuario: req.body.usuario, password: req.body.password});//es para poder encontrar un registro, las condiciones/metodos se pasan en formato json,del lado izquierdo va lo q esta en la base de datos,ej usuario y del lado derecho va req.body.usuario q es lo q recibe en ese campo. findone es una consulta a la base de datos y como es una consulta va con await y hay q guardar esa peticion en una variable, ej usr
    
    if (usr) {
        req.session.usuario_id = usr._id;
        res.json(usr);//va a retornar el usuario q esta logueado en la aplicacion
    } else {
        res.status(404).send();//si no encontro el usuario,se envia un 404
    }
});

//---------------//---------------//---------------//


app.listen(3000, function() {
    console.log('Corriendo en el puerto 3000');
});



